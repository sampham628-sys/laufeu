import json
import customtkinter as ctk
import time
import tkinter as tk


FILE_PATH = r"C:\Users\sam.pham628\OneDrive - NSW Department of Education\Desktop\mytest\cards.json"
#Change file path if needed or else the program can't work normally


def load_cards():
    try:
        with open(FILE_PATH, "r") as f:
            return json.load(f)
    except:
        return []

def save_cards(cards):
    with open(FILE_PATH, "w") as f:
        json.dump(cards, f, indent=4)

def up_cards(card, got_it, current):
    if got_it:
        card["level"] += 1
    else:
        card["level"] = 1
    card["due"] = current + card["level"] * 2

def select_due_cards(cards, current):
    return [c for c in cards if c["due"] <= current]


class FlashApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Flashcards")
        self.geometry("700x600")
        self.configure(fg_color="#1a1a1a")

        self.cards = load_cards()
        self.current_time = 0
        self.current_card = None

        self.main_menu()

    
    def clear(self):
        for widget in self.winfo_children():
            widget.destroy()

    def start_again(self):
        self.clear()
        self.current_time = 0

        for card in self.cards:
            card["due"] = 0
            card["level"] = 1

        save_cards(self.cards)
        self.study_screen()

    def delete(self):
        self.cards = []
        self.show_cards_screen()
        with open(FILE_PATH, "w") as f:
            json.dump([], f)


       
 

    


    
    def main_menu(self):
        self.clear()

        title = ctk.CTkLabel(self, text="Flashcards", font=("Arial Rounded MT Bold", 32))
        title.pack(pady=40)

        ctk.CTkButton(self, text="Study", width=200, height=45, corner_radius=12,
                      command=self.study_screen).pack(pady=10)

        ctk.CTkButton(self, text="Add Card", width=200, height=45, corner_radius=12,
                      command=self.add_card_screen).pack(pady=10)

        ctk.CTkButton(self, text="Saved Cards", width=200, height=45, corner_radius=12,
                      command=self.show_cards_screen).pack(pady=10)

        ctk.CTkButton(self, text="Exit", width=200, height=45, corner_radius=12,
                      command=self.destroy).pack(pady=10)

    
    def add_card_screen(self):
        self.clear()

        ctk.CTkLabel(self, text="Add New Card", font=("Arial Rounded MT Bold", 26)).pack(pady=20)

        front_entry = ctk.CTkEntry(self, placeholder_text="Front", width=300)
        front_entry.pack(pady=10)
        front_entry.bind("<Return>", lambda event: save_new())


        back_entry = ctk.CTkEntry(self, placeholder_text="Back", width=300)
        back_entry.pack(pady=10)
        back_entry.bind("<Return>", lambda event: save_new())
       



        def save_new():
            front = front_entry.get()
            back = back_entry.get()
            if front and back:
                self.cards.append({"front": front, "back": back, "level": 1, "due": 0})
                save_cards(self.cards)
                front_entry.delete(0, ctk.END)
                back_entry.delete(0, ctk.END)
                

        ctk.CTkButton(self, text="Save", width=200, height=40, corner_radius=12,
                      command=save_new).pack(pady=20)

        ctk.CTkButton(self, text="Back", width=200, height=40, corner_radius=12,
                      command=self.main_menu).pack()

    
    def study_screen(self):
        self.clear()
        due_cards = select_due_cards(self.cards, self.current_time)

        if not due_cards:
            ctk.CTkLabel(self, text="No cards due!", font=("Arial Rounded MT Bold", 26)).pack(pady=40)
            ctk.CTkButton(self, text="Study again?", width=200, height=40, corner_radius=12,
                          command=self.start_again).pack(pady=10)
            ctk.CTkButton(self, text="Back", width=200, height=40, corner_radius=12,
                          command=self.main_menu).pack(pady=10)
            return

        self.current_card = due_cards[0]
        
        
        self.card_frame = ctk.CTkFrame(self, width=400, height=250, corner_radius=20, fg_color="#2b2b2b")
        self.card_frame.pack(pady=60)

        self.card_label = ctk.CTkLabel(self.card_frame, text=self.current_card["front"],
                                       font=("Arial Rounded MT Bold", 28), wraplength=350)
        self.card_label.place(relx=0.5, rely=0.5, anchor="center")

        ctk.CTkButton(self, text="Flip", width=200, height=40, corner_radius=12,
                      command=self.flip_card).pack(pady=10)

   
    def flip_card(self):
        self.card_label.configure(text=self.current_card["back"])
        ctk.CTkButton(self, text="I knew it", width=200, height=40, corner_radius=12,
                      command=lambda: self.swipe(True)).pack(pady=5)

        ctk.CTkButton(self, text="I forgot", width=200, height=40, corner_radius=12,
                      command=lambda: self.swipe(False)).pack(pady=5)

   
    def swipe(self, got_it):
        
        for x in range(0, 300, 10):
            self.card_frame.place(x=x)
            self.update()
            time.sleep(0.01)

        up_cards(self.current_card, got_it, self.current_time)
        self.current_time += 1
        save_cards(self.cards)

        
        time.sleep(0.15)

        self.study_screen()

    
    def show_cards_screen(self):
        self.clear()

        ctk.CTkLabel(self, text="Saved Cards", font=("Arial Rounded MT Bold", 26)).pack(pady=20)

        frame = ctk.CTkScrollableFrame(self, width=450, height=300)
        frame.pack(pady=10)

        for card in self.cards:
            ctk.CTkLabel(frame, text=f"{card['front']} ➞ {card['back']}",
                         font=("Arial", 18), cursor="hand2").pack(anchor="w", pady=4)
    


        ctk.CTkButton(self, text="Delete all", width=200, height=40, corner_radius=12,
                      command=self.delete).pack(pady=10)
        ctk.CTkButton(self, text="Back", width=200, height=40, corner_radius=12,
                      command=self.main_menu).pack(pady=10)
        

    
        
       
        


        




ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

app = FlashApp()
app.mainloop()
